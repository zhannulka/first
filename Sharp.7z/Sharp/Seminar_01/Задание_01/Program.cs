﻿// Задача 2: Напишите программу, которая на вход 
// принимает два числа и выдаёт, какое число большее, а какое меньшее.

// a = 5; b = 7 -> max = 7
// a = 2 b = 10 -> max = 10
// a = -9 b = -3 -> max = -3

Console.Write("Введите первое число: ");
int firstnumber = Convert.ToInt32(Console.ReadLine());
Console.Write("Введите второе чиcло: ");
int secondnumber = Convert.ToInt32(Console.ReadLine());
if (firstnumber > secondnumber)
{
    int square1 = firstnumber;
    int square2 = secondnumber;
    System.Console.WriteLine($"Первое число {square1} больше чем второе {square2}");
}
else
{
    int square1 = secondnumber;
    int square2 = firstnumber;
    System.Console.WriteLine($"Второе число {square1} больше чем первое {square2}");
}
